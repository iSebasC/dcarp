<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarcaBateria extends Model
{
    protected $table = 'marcabateria';
    protected $primaryKey = 'id';
}
