<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class OpcionTaller extends Model
{
    //
    protected $table = 'checktaller';
    public $timestamps = false;
  
}
