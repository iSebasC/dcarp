<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModeloLlanta extends Model
{
    protected $table = 'modelollanta';
    protected $primaryKey = 'id';
}
