<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class OpcionInventario extends Model
{
    //
    protected $table = 'checkinventario';
    public $timestamps = false;
  
}
