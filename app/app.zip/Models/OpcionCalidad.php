<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OpcionCalidad extends Model
{
    //
    protected $table = 'checkcalidad';
    public $timestamps = false;
  
}
