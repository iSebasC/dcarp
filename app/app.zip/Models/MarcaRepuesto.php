<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarcaRepuesto extends Model
{
    protected $table = 'marcaaccesorio';
    protected $primaryKey = 'id';
}
