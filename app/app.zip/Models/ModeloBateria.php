<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModeloBateria extends Model
{
    protected $table = 'modelobateria';
    protected $primaryKey = 'id';
}
