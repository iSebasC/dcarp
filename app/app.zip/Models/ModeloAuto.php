<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModeloAuto extends Model
{
    protected $table = 'modeloauto';
    protected $primaryKey = 'id';
}
