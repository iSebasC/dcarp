<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RespuestaCheckInventario extends Model
{
    use SoftDeletes;

    protected $table = 'rptacheckinventario';
    protected $primaryKey = 'id';
  
}
