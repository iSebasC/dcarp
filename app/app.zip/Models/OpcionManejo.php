<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OpcionManejo extends Model
{
    //
    protected $table = 'checkmanejo';
    public $timestamps = false;
  
}
