<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EtiquetaProspecto extends Model
{
    protected $table = 'etiquetaprospecto';
    protected $primaryKey = 'id';
}
