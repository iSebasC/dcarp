<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarcaLlanta extends Model
{
    protected $table = 'marcallanta';
    protected $primaryKey = 'id';
}
