<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarcaAuto extends Model
{
    protected $table = 'marcaauto';
    protected $primaryKey = 'id';
}
