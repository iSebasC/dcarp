<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServicioUsuario extends Model
{
    //
    protected $table = 'serviciousuario';
    public $timestamps = false;
  
}
