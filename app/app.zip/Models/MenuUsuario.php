<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenuUsuario extends Model
{
    //
    protected $table = 'menuusuario';
    public $timestamps = false;
  
}
