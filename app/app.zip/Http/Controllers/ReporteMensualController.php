<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Forma;
use App\Models\CategoriaProducto;
use App\Models\Acabado;
use App\Models\Venta;
use App\Models\DetalleVenta;
use App\Models\UnidadMedida;
use App\Models\Local;
use App\Models\StockProducto;
use App\Models\StockProductoDetalleSalida;
use App\Models\StockProductoDetalle;

use App\Models\Producto;
use App\Models\Persona;
use App\Models\Serie;
use App\Models\MovimientoCaja;
use App\Models\Cotizacion;
use App\Models\Anulacion;
use App\Models\AnulacionNotas;
use App\Models\DetalleCotizacion;
use App\Models\DetalleOrdenTrabajo;
use App\Models\DetalleHomologacion;

use App\Models\OrdenTrabajo;
use App\Models\PagoDetalle;
use App\Models\SerieDocumento;

use App\Libraries\Funciones;

use DB;
use Validator;
use Auth;

use PhpOffice\PhpSpreadsheet\Spreadsheet	 as PHPExcel;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx	 as PHPExcel_IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Border 	 as PHPExcel_Style_Border;
use PhpOffice\PhpSpreadsheet\Style\Fill 	 as PHPExcel_Style_Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment as PHPExcel_Style_Alignment;


class ReporteMensualController extends Controller
{
	public $estilo_content = array( 
		'alignment' => array(
			'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
		)
	);

	public function reporteMesExcel (Request $request) {
        ini_set('memory_limit', '-1');
        $tipo 	 	= $request->get('tipo');
		$fechai 	= $request->get('fechai');
		$fechaf 		= $request->get('fechaf');
        
		$excel = new PHPExcel(); 
        $fileName = $this->getReporteExcel($fechai, $fechaf, $tipo, $excel);
		$objWriter = new PHPExcel_IOFactory($excel);		
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'.$fileName.'.xlsx"');
		header('Cache-Control: max-age=0');
		$objWriter->save('php://output');
	
	}

    public function reporteClienteExcel(Request $request) {
        ini_set('memory_limit', '-1');
        $tipo 	 	= $request->get('tipo');
		$fechai 	= $request->get('fechai');
		$fechaf     = $request->get('fechaf');
        $cliente    = (!is_null($request->get('cli'))?$request->get('cli'):'');

		$excel = new PHPExcel(); 
        $fileName = $this->getReporteClienteExcel($fechai, $fechaf, $tipo, $cliente, $excel);
		$objWriter = new PHPExcel_IOFactory($excel);		
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'.$fileName.'.xlsx"');
		header('Cache-Control: max-age=0');
		$objWriter->save('php://output');
    }

    public function getReporteClienteExcel($fechaI, $fechaF, $tipo, $cliente, $excel) {
        
        $data = $this->getDataCliente($fechaI, $fechaF, $tipo, $cliente);
        $excel->setActiveSheetIndex(0);
		$hoja1 = $excel->getActiveSheet();
		$fileName = '';
        if ($tipo == 1) {
            $fileName = 'orden_detallada'; 
            $hoja1->setTitle("orden_detallada");

            $j = 1;
            $elem = null;
            $data_Final = [];
            $detalles = [];
            foreach ($data as $value) {
                if (is_null($elem)) { $elem = $value; }
                if ($elem->keyI == $value->keyI) {
                    $detalles[] = $value;
                } else {
                    // dd($detalles);
                    $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                    $elem = null;
                    $detalles = [];
                }
            }
            if (count($detalles)>0) {
                $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                $elem = null;
                $detalles = [];
            }
            

            foreach ($data_Final as $value) {
                $elem = $value['cabecera'];
                $hoja1->setCellValue('A'.$j,'doc_cliente');
                $hoja1->setCellValue('B'.$j,'cliente');
                $hoja1->setCellValue('C'.$j,'celular');
                $hoja1->setCellValue('D'.$j,'correo_electronico');
                // $hoja1->setCellValue('E'.$j,'placa');
                // $hoja1->setCellValue('F'.$j,'marca');
                // $hoja1->setCellValue('G'.$j,'modelo');
                // $hoja1->setCellValue('H'.$j,'vin');
                // $hoja1->setCellValue('I'.$j,'kilometraje');
                
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,$elem->documentoCliente);
                $hoja1->setCellValue('B'.$j,$elem->cliente);
                $hoja1->setCellValue('C'.$j,$elem->celular);
                $hoja1->setCellValue('D'.$j,$elem->correoElectronico);
                // $hoja1->setCellValue('J'.$j,$elem->fecha);
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,'fecha_orden');
                $hoja1->setCellValue('B'.$j,'orden_trabajo');
                $hoja1->setCellValue('C'.$j,'cotizacion');
                $hoja1->setCellValue('D'.$j,'cantidad');
                $hoja1->setCellValue('E'.$j,'detalle');
                $hoja1->setCellValue('F'.$j,'inicia');
                $hoja1->setCellValue('G'.$j,'finaliza');
           
                $hoja1->setCellValue('H'.$j,'placa');
                $hoja1->setCellValue('I'.$j,'marca');
                $hoja1->setCellValue('J'.$j,'modelo');
                $hoja1->setCellValue('K'.$j,'vin');
                $hoja1->setCellValue('L'.$j,'kilometraje');
                $hoja1->setCellValue('M'.$j,'venta');
           
                $hoja1->setCellValue('N'.$j,'personal_registra');
                $hoja1->setCellValue('O'.$j,'asignado_a');
                $hoja1->setCellValue('P'.$j,'facturado');
                $hoja1->setCellValue('Q'.$j,'fecha_reg');
                $hoja1->setCellValue('R'.$j,'situacion');
                $hoja1->getStyle('A'.$j.':R'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $detalles = $value['detalles'];
                // dd($detalles);
                foreach ($detalles as $value2) {
                    $hoja1->setCellValue('A'.$j,$value2->fecha);
                    $hoja1->setCellValue('B'.$j,$value2->orden);
                    $hoja1->setCellValue('C'.$j,$value2->cotizacion);
                    $hoja1->setCellValue('D'.$j,number_format($value2->cantidad,2,'.',''));
                    $hoja1->setCellValue('E'.$j,$value2->detalle);
                    $hoja1->setCellValue('F'.$j,$value2->inicia);
                    $hoja1->setCellValue('G'.$j,$value2->finaliza);
           
                    $hoja1->setCellValue('H'.$j,$value2->placa);
                    if (!is_null($value2->marcamodelo)) {
                        $hoja1->setCellValue('I'.$j,$this->getExplodeStringReport($value2->marcamodelo, 0,'/'));
                        $hoja1->setCellValue('J'.$j,$this->getExplodeStringReport($value2->marcamodelo, 1,'/'));
                    }

                    $hoja1->setCellValue('K'.$j,$value2->vin);
                    $hoja1->setCellValue('L'.$j,$value2->kilometraje);
                    $hoja1->setCellValue('M'.$j,$value2->venta);
           
                    $hoja1->setCellValue('N'.$j,$value2->personal);
                    $hoja1->setCellValue('O'.$j,$value2->trabajador);
                    $hoja1->setCellValue('P'.$j,($value2->situacionFacturado=='N'?'No':'Si'));
                    $hoja1->setCellValue('Q'.$j, $value2->fechaReg);
                    $hoja1->setCellValue('R'.$j, ($value2->situacion == 'A'?'Anulado':'Vigente'));
                    
                    $hoja1->getStyle('A'.$j.':R'.$j)->applyFromArray($this->estilo_content);
                    $j++;
                }
                $j++;
                // } else {
                //     if ($elem != $value->orden) {
                //         $elem = $value;

                //         $hoja1->setCellValue('A'.$j,'doc_cliente');
                //         $hoja1->setCellValue('B'.$j,'cliente');
                //         $hoja1->setCellValue('C'.$j,'celular');
                //         $hoja1->setCellValue('D'.$j,'correo_electronico');
                //         $hoja1->setCellValue('E'.$j,'placa');
                //         $hoja1->setCellValue('F'.$j,'marca');
                //         $hoja1->setCellValue('G'.$j,'modelo');
                //         $hoja1->setCellValue('H'.$j,'vin');
                //         $hoja1->setCellValue('I'.$j,'kilometraje');
                //         $hoja1->getStyle('A'.$j.':I'.$j)->applyFromArray($this->estilo_content);
                  
                //         $j++;

                //         $hoja1->setCellValue('A'.$j,$elem->documentoCliente);
                //         $hoja1->setCellValue('B'.$j,$elem->cliente);
                //         $hoja1->setCellValue('C'.$j,$elem->celular);
                //         $hoja1->setCellValue('D'.$j,$elem->correoElectronico);
                //         $hoja1->setCellValue('E'.$j,$elem->placa);
                //         $hoja1->setCellValue('F'.$j,$elem->marcamodelo);
                //         $hoja1->setCellValue('G'.$j,$elem->marcamodelo);
                //         $hoja1->setCellValue('H'.$j,$elem->vin);
                //         $hoja1->setCellValue('I'.$j,$elem->kilometraje);
                //         $hoja1->getStyle('A'.$j.':I'.$j)->applyFromArray($this->estilo_content);
                //         $j++;

                //         $hoja1->setCellValue('A'.$j,'fecha_orden');
                //         $hoja1->setCellValue('B'.$j,'orden_trabajo');
                //         $hoja1->setCellValue('C'.$j,'cotizacion');
                //         $hoja1->setCellValue('D'.$j,'cantidad');
                //         $hoja1->setCellValue('E'.$j,'detalle');
                //         $hoja1->setCellValue('F'.$j,'inicia');
                //         $hoja1->setCellValue('G'.$j,'finaliza');
                //         $hoja1->setCellValue('H'.$j,'asignado_a');
                //         $hoja1->setCellValue('I'.$j,'facturado');
                //         $hoja1->setCellValue('J'.$j,'fecha_reg');
                //         $hoja1->setCellValue('K'.$j,'situacion');
                //         $hoja1->getStyle('A'.$j.':K'.$j)->applyFromArray($this->estilo_content);
                //         $j++;
    
    
                //     }
                // }
          
                // foreach ($data as $value2) {
                //     if (!is_null($elem) && $elem->orden == $value2->orden) {
                //         $hoja1->setCellValue('A'.$j,$value->fecha);
                //         $hoja1->setCellValue('B'.$j,$value->orden);
                //         $hoja1->setCellValue('C'.$j,$value->cotizacion);
                //         $hoja1->setCellValue('D'.$j,number_format($value->cantidad,2,'.',''));
                //         $hoja1->setCellValue('E'.$j,$value->detalle);
                //         $hoja1->setCellValue('F'.$j,$value->inicia);
                //         $hoja1->setCellValue('G'.$j,$value->finaliza);
                //         $hoja1->setCellValue('H'.$j,$value->trabajador);
                //         $hoja1->setCellValue('I'.$j,($value->situacionFacturado=='N'?'No':'Si'));
                //         $hoja1->setCellValue('J'.$j, $value->fechaReg);
                //         $hoja1->setCellValue('K'.$j, ($value->situacion == 'A'?'Anulado':'Vigente'));
                        
                //         $hoja1->getStyle('A'.$j.':K'.$j)->applyFromArray($this->estilo_content);
                //         $j++;

                //         $elem = $value2;
                //     }
                // }
               
            }
        } elseif($tipo == 2) {
            $fileName = 'cot_detallada'; 
            $hoja1->setTitle("cot_detallada");
            
            $j = 1;
            $elem = null;
            $data_Final = [];
            $detalles = [];
            foreach ($data as $value) {
                if (is_null($elem)) { $elem = $value; }
                if ($elem->keyI == $value->keyI) {
                    $detalles[] = $value;
                } else {
                    $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                    $elem = null;
                    $detalles = [];
                }
            }
            if (count($detalles)>0) {
                $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                $elem = null;
                $detalles = [];
            }
            
            foreach ($data_Final as $value) {
                $elem = $value['cabecera'];
                $hoja1->setCellValue('A'.$j,'doc_cliente');
                $hoja1->setCellValue('B'.$j,'cliente');
                $hoja1->setCellValue('C'.$j,'celular');
                $hoja1->setCellValue('D'.$j,'correo_electronico');
                // $hoja1->setCellValue('E'.$j,'placa');
                // $hoja1->setCellValue('F'.$j,'marca');
                // $hoja1->setCellValue('G'.$j,'modelo');
                // $hoja1->setCellValue('H'.$j,'vin');
                // $hoja1->setCellValue('I'.$j,'kilometraje');
                    // $hoja1->setCellValue('J'.$j,'fecha_orden');
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,$elem->documentoCliente);
                $hoja1->setCellValue('B'.$j,$elem->cliente);
                $hoja1->setCellValue('C'.$j,$elem->celular);
                $hoja1->setCellValue('D'.$j,$elem->correoElectronico);
                // $hoja1->setCellValue('E'.$j,$elem->placa);
                // $hoja1->setCellValue('F'.$j,$this->getExplodeMarcaModeloString($elem->marcamodelo,0));
                // $hoja1->setCellValue('G'.$j,$this->getExplodeMarcaModeloString($elem->marcamodelo,1));
                // $hoja1->setCellValue('H'.$j,$elem->vin);
                // $hoja1->setCellValue('I'.$j,$elem->kilometraje);
                // $hoja1->setCellValue('J'.$j,$elem->fecha);
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,'fecha_cot');
                $hoja1->setCellValue('B'.$j,'cotizacion');
                $hoja1->setCellValue('C'.$j,'cantidad');
                $hoja1->setCellValue('D'.$j,'detalle');
                $hoja1->setCellValue('E'.$j,'personal_registra');
                
                $hoja1->setCellValue('F'.$j,'placa');
                $hoja1->setCellValue('G'.$j,'marca');
                $hoja1->setCellValue('H'.$j,'modelo');
                $hoja1->setCellValue('I'.$j,'vin');
                $hoja1->setCellValue('J'.$j,'kilometraje');
                $hoja1->setCellValue('K'.$j,'venta');
                
                $hoja1->setCellValue('L'.$j,'facturado');
                $hoja1->setCellValue('M'.$j,'fecha_reg');
                $hoja1->setCellValue('N'.$j,'situacion');
                $hoja1->getStyle('A'.$j.':N'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $detalles = $value['detalles'];
                foreach ($detalles as $value2) {
                    $hoja1->setCellValue('A'.$j,$value2->fecha);
                    $hoja1->setCellValue('B'.$j,$value2->cotizacion);
                    $hoja1->setCellValue('C'.$j,number_format($value2->cantidad,2,'.',''));
                    $hoja1->setCellValue('D'.$j,$value2->detalle);
                    $hoja1->setCellValue('E'.$j, $value2->personal);

                    $hoja1->setCellValue('F'.$j,$value2->placa);
                    if (!is_null($value2->marcamodelo)) {
                        $hoja1->setCellValue('G'.$j,$this->getExplodeStringReport($value2->marcamodelo, 0,'/'));
                        $hoja1->setCellValue('H'.$j,$this->getExplodeStringReport($value2->marcamodelo, 1,'/'));
                    }

                    $hoja1->setCellValue('I'.$j,$value2->vin);
                    $hoja1->setCellValue('J'.$j,$value2->kilometraje);
                    $hoja1->setCellValue('K'.$j,$value2->venta);
        

                    $hoja1->setCellValue('L'.$j,($value2->situacionFacturado=='N'?'No':'Si'));
                    $hoja1->setCellValue('M'.$j, $value2->fechaReg);
                    $hoja1->setCellValue('N'.$j, ($value2->situacion == 'A'?'Anulado':'Vigente'));
                    
                    $hoja1->getStyle('A'.$j.':N'.$j)->applyFromArray($this->estilo_content);
                    $j++;
                }
                $j++;
            }
        } elseif($tipo == 3) {
            $fileName = 'vt_detallada_cliente'; 
            $hoja1->setTitle("vt_detallada_cliente");
            $j = 1;
            $elem = null;
            $data_Final = [];
            $detalles = [];
            foreach ($data as $value) {
                if (is_null($elem)) { $elem = $value; }
                if ($elem->keyI == $value->keyI) {
                    $detalles[] = $value;
                } else {
                    $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                    $elem = null;
                    $detalles = [];
                }
            }
            if (count($detalles)>0) {
                $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                $elem = null;
                $detalles = [];
            }
            foreach ($data_Final as $value) {
                $elem = $value['cabecera'];
                $hoja1->setCellValue('A'.$j,'doc_cliente');
                $hoja1->setCellValue('B'.$j,'cliente');
                $hoja1->setCellValue('C'.$j,'celular');
                $hoja1->setCellValue('D'.$j,'correo_electronico');
                // $hoja1->setCellValue('E'.$j,'placa');
                // $hoja1->setCellValue('F'.$j,'marca');
                // $hoja1->setCellValue('G'.$j,'modelo');
                // $hoja1->setCellValue('H'.$j,'vin');
                // $hoja1->setCellValue('I'.$j,'kilometraje');
                // $hoja1->setCellValue('J'.$j,'fecha_orden');
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,$elem->documentoCliente);
                $hoja1->setCellValue('B'.$j,$elem->cliente);
                $hoja1->setCellValue('C'.$j,$elem->celular);
                $hoja1->setCellValue('D'.$j,$elem->correoElectronico);
                // $hoja1->setCellValue('E'.$j,$elem->placa);
                // $hoja1->setCellValue('F'.$j,$this->getExplodeMarcaModeloString($elem->marcamodelo,0));
                // $hoja1->setCellValue('G'.$j,$this->getExplodeMarcaModeloString($elem->marcamodelo,1));
                // $hoja1->setCellValue('H'.$j,$elem->vin);
                // $hoja1->setCellValue('I'.$j,$elem->kilometraje);
                // $hoja1->setCellValue('J'.$j,$elem->fecha);
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,'fecha_vt');
                $hoja1->setCellValue('B'.$j,'venta');
                $hoja1->setCellValue('C'.$j,'referencia');
                $hoja1->setCellValue('D'.$j,'cantidad');
                $hoja1->setCellValue('E'.$j,'detalle');
                $hoja1->setCellValue('F'.$j,'personal_registra');

                $hoja1->setCellValue('G'.$j,'placa');
                $hoja1->setCellValue('H'.$j,'marca');
                $hoja1->setCellValue('I'.$j,'modelo');
                $hoja1->setCellValue('J'.$j,'vin');
                $hoja1->setCellValue('K'.$j,'kilometraje');
               
                $hoja1->setCellValue('L'.$j,'fecha_reg');
                $hoja1->setCellValue('M'.$j,'situacion');
                $hoja1->getStyle('A'.$j.':M'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $detalles = $value['detalles'];
                foreach ($detalles as $value2) {
                    $hoja1->setCellValue('A'.$j,$value2->fecha);
                    $hoja1->setCellValue('B'.$j,$value2->venta);
                    $hoja1->setCellValue('C'.$j,$value2->referencia);
                    $hoja1->setCellValue('D'.$j,number_format($value2->cantidad,2,'.',''));
                    $hoja1->setCellValue('E'.$j,$value2->detalle);
                    $hoja1->setCellValue('F'.$j,$value2->personal);
                    
                    if (!is_null($value2->params)) {
                        // (ct.placa,'@@', ct.kilometraje, '@@', ct.marcamodelo,'@@', ct.vin)
                        $hoja1->setCellValue('G'.$j,$this->getExplodeStringReport($value2->params, 0,'@@'));
                        $hoja1->setCellValue('H'.$j,$this->getExplodeStringReport($this->getExplodeStringReport($value2->params, 2,'@@'),0,'/'));
                        $hoja1->setCellValue('I'.$j,$this->getExplodeStringReport($this->getExplodeStringReport($value2->params, 2,'@@'),1,'/'));
                        $hoja1->setCellValue('J'.$j,$this->getExplodeStringReport($value2->params, 3,'@@'));
                        $hoja1->setCellValue('K'.$j,$this->getExplodeStringReport($value2->params, 1,'@@'));
                    }    
                    
                    $hoja1->setCellValue('L'.$j, $value2->fechaReg);
                    $hoja1->setCellValue('M'.$j, ($value2->situacion == 'A'?'Anulado':'Vigente'));
                    
                    $hoja1->getStyle('A'.$j.':M'.$j)->applyFromArray($this->estilo_content);
    
                    $j++;
                }
                $j++;
            }
            // $hoja1->setCellValue('A1','fecha_vt');
            // $hoja1->setCellValue('B1','doc_cliente');
            // $hoja1->setCellValue('C1','cliente');
            // $hoja1->setCellValue('D1','venta');
            // $hoja1->setCellValue('E1','referencia');
            // $hoja1->setCellValue('F1','cantidad');
            // $hoja1->setCellValue('G1','detalle');
            // $hoja1->setCellValue('H1','asesor');
            // $hoja1->setCellValue('I1','fecha_reg');
            // $hoja1->setCellValue('J1','situacion');
            // $hoja1->getStyle('A1:J1')->applyFromArray($this->estilo_content);
            
            // $j = 2;
            // foreach ($data as $value) {
            //     $hoja1->setCellValue('A'.$j,$value->fecha);
            //     $hoja1->setCellValue('B'.$j,$value->documentoCliente);
            //     $hoja1->setCellValue('C'.$j,$value->cliente);
            //     $hoja1->setCellValue('D'.$j,$value->venta);
            //     $hoja1->setCellValue('E'.$j,$value->referencia);
            //     $hoja1->setCellValue('F'.$j,number_format($value->cantidad,2,'.',''));
            //     $hoja1->setCellValue('G'.$j,$value->detalle);
            //     $hoja1->setCellValue('H'.$j,$value->asesorAuto);
            //     $hoja1->setCellValue('I'.$j, $value->fechaReg);
            //     $hoja1->setCellValue('J'.$j, ($value->situacion == 'A'?'Anulado':'Vigente'));
                
            //     $hoja1->getStyle('A'.$j.':J'.$j)->applyFromArray($this->estilo_content);

            //     $j++;
            // }
        } elseif($tipo == 4) {
            $fileName = 'vt_detallada_veh_cliente'; 
            $hoja1->setTitle("vt_detallada_veh_cliente");
            $j = 1;
            $elem = null;
            $data_Final = [];
            $detalles = [];
            foreach ($data as $value) {
                if (is_null($elem)) { $elem = $value; }
                if ($elem->keyI == $value->keyI) {
                    $detalles[] = $value;
                } else {
                    $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                    $elem = null;
                    $detalles = [];
                }
            }
            if (count($detalles)>0) {
                $data_Final[] = ['cabecera' => $elem, 'detalles' => $detalles];
                $elem = null;
                $detalles = [];
            }
            foreach ($data_Final as $value) {
                $elem = $value['cabecera'];
                $hoja1->setCellValue('A'.$j,'doc_cliente');
                $hoja1->setCellValue('B'.$j,'cliente');
                $hoja1->setCellValue('C'.$j,'celular');
                $hoja1->setCellValue('D'.$j,'correo_electronico');
                // $hoja1->setCellValue('E'.$j,'placa');
                // $hoja1->setCellValue('F'.$j,'marca');
                // $hoja1->setCellValue('G'.$j,'modelo');
                // $hoja1->setCellValue('H'.$j,'vin');
                // $hoja1->setCellValue('I'.$j,'kilometraje');
                // $hoja1->setCellValue('J'.$j,'fecha_orden');
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,$elem->documentoCliente);
                $hoja1->setCellValue('B'.$j,$elem->cliente);
                $hoja1->setCellValue('C'.$j,$elem->celular);
                $hoja1->setCellValue('D'.$j,$elem->correoElectronico);
                // $hoja1->setCellValue('E'.$j,$elem->placa);
                // $hoja1->setCellValue('F'.$j,$this->getExplodeMarcaModeloString($elem->marcamodelo,0));
                // $hoja1->setCellValue('G'.$j,$this->getExplodeMarcaModeloString($elem->marcamodelo,1));
                // $hoja1->setCellValue('H'.$j,$elem->vin);
                // $hoja1->setCellValue('I'.$j,$elem->kilometraje);
                // $hoja1->setCellValue('J'.$j,$elem->fecha);
                $hoja1->getStyle('A'.$j.':D'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $hoja1->setCellValue('A'.$j,'fecha_vt');
                $hoja1->setCellValue('B'.$j,'venta');
                // $hoja1->setCellValue('C'.$j,'referencia');
                $hoja1->setCellValue('C'.$j,'cantidad');
                $hoja1->setCellValue('D'.$j,'detalle');
                $hoja1->setCellValue('E'.$j,'personal_registra');
                $hoja1->setCellValue('F'.$j,'asesor_auto');
                $hoja1->setCellValue('G'.$j,'fecha_reg');
                $hoja1->setCellValue('H'.$j,'situacion');
                $hoja1->getStyle('A'.$j.':H'.$j)->applyFromArray($this->estilo_content);
                $j++;

                $detalles = $value['detalles'];
                foreach ($detalles as $value2) {
                    $hoja1->setCellValue('A'.$j,$value2->fecha);
                    $hoja1->setCellValue('B'.$j,$value2->venta);
                    // $hoja1->setCellValue('C'.$j,$value2->referencia);
                    $hoja1->setCellValue('C'.$j,number_format($value2->cantidad,2,'.',''));
                    $hoja1->setCellValue('D'.$j,$value2->detalle);
                    $hoja1->setCellValue('E'.$j,$value2->personal);
                    $hoja1->setCellValue('F'.$j, $value2->asesorAuto);
                    $hoja1->setCellValue('G'.$j, $value2->fechaReg);
                    $hoja1->setCellValue('H'.$j, ($value2->situacion == 'A'?'Anulado':'Vigente'));
                    
                    $hoja1->getStyle('A'.$j.':H'.$j)->applyFromArray($this->estilo_content);
    
                    $j++;
                }
                $j++;
            }
            // $hoja1->setCellValue('A1','fecha_vt');
            // $hoja1->setCellValue('B1','doc_cliente');
            // $hoja1->setCellValue('C1','cliente');
            // $hoja1->setCellValue('D1','venta');
            // $hoja1->setCellValue('E1','referencia');
            // $hoja1->setCellValue('F1','cantidad');
            // $hoja1->setCellValue('G1','detalle');
            // $hoja1->setCellValue('H1','asesor');
            // $hoja1->setCellValue('I1','fecha_reg');
            // $hoja1->setCellValue('J1','situacion');
            // $hoja1->getStyle('A1:J1')->applyFromArray($this->estilo_content);
            
            // $j = 2;
            // foreach ($data as $value) {
            //     $hoja1->setCellValue('A'.$j,$value->fecha);
            //     $hoja1->setCellValue('B'.$j,$value->documentoCliente);
            //     $hoja1->setCellValue('C'.$j,$value->cliente);
            //     $hoja1->setCellValue('D'.$j,$value->venta);
            //     $hoja1->setCellValue('E'.$j,$value->referencia);
            //     $hoja1->setCellValue('F'.$j,number_format($value->cantidad,2,'.',''));
            //     $hoja1->setCellValue('G'.$j,$value->detalle);
            //     $hoja1->setCellValue('H'.$j,$value->asesorAuto);
            //     $hoja1->setCellValue('I'.$j, $value->fechaReg);
            //     $hoja1->setCellValue('J'.$j, ($value->situacion == 'A'?'Anulado':'Vigente'));
                
            //     $hoja1->getStyle('A'.$j.':J'.$j)->applyFromArray($this->estilo_content);

            //     $j++;
            // }
        } elseif($tipo == 5) {
            $fileName = 'vt_cliente_marketing'; 
            $hoja1->setTitle("vt_cliente_marketing");
            $j = 1;
            $hoja1->setCellValue('A'.$j,'doc_cliente');
            $hoja1->setCellValue('B'.$j,'cliente');
            $hoja1->setCellValue('C'.$j,'celular');
            $hoja1->setCellValue('D'.$j,'correo_electronico');
            $hoja1->setCellValue('E'.$j,'marca');
            $hoja1->setCellValue('F'.$j,'modelo');
            $hoja1->setCellValue('G'.$j,'placa');
            $hoja1->getStyle('A'.$j.':G'.$j)->applyFromArray($this->estilo_content);
                 

            foreach ($data as $elem) {
                $j++;
                $hoja1->setCellValue('A'.$j,$elem->documento);
                $hoja1->setCellValue('B'.$j,$elem->cliente);
                $hoja1->setCellValue('C'.$j,$elem->telefono);
                $hoja1->setCellValue('D'.$j,$elem->correoElectronico);
                $hoja1->setCellValue('E'.$j,$elem->marca);
                $hoja1->setCellValue('F'.$j,$elem->modelo);
                $hoja1->setCellValue('G'.$j,$elem->placa);
                $hoja1->getStyle('A'.$j.':G'.$j)->applyFromArray($this->estilo_content);
            }
        } elseif (in_array($tipo, [11,22,33,44])) {
            $fileName = ($tipo == 11?'orden_gen_detallada':($tipo == 22?'cot_gen_detallada':($tipo == 33?'vt_detallada_gen_cliente':'vt_detallada_gen_vehi_cliente'))); 
            $hoja1->setTitle("$fileName");
            $hoja1->setCellValue('A1','doc_cliente');
            $hoja1->setCellValue('B1','cliente');
            $hoja1->setCellValue('C1','celular');
            $hoja1->setCellValue('D1','correo_electronico');
            $hoja1->setCellValue('E1','direcci贸n');
            
            if (in_array($tipo, [11,22,33])) {
                $hoja1->setCellValue('F1','placa');
                $hoja1->setCellValue('G1','kilometraje');
                $hoja1->setCellValue('H1','marca');
                $hoja1->setCellValue('I1','modelo');
                $hoja1->setCellValue('J1','fecha_registro');
                $hoja1->getStyle('A1:J1')->applyFromArray($this->estilo_content);
            } else {
                $hoja1->setCellValue('F1','asesor');
                $hoja1->setCellValue('G1','descripci贸n');
                $hoja1->setCellValue('H1','fecha');
                //$hoja1->setCellValue('I1','fecha_registro');
                $hoja1->getStyle('A1:H1')->applyFromArray($this->estilo_content);
            }
            
            $j = 2;
            foreach ($data as $value) {
                $hoja1->setCellValue('A'.$j,$value->documento);
                $hoja1->setCellValue('B'.$j,$value->cliente);
                $hoja1->setCellValue('C'.$j,$value->celular);
                $hoja1->setCellValue('D'.$j,$value->correoElectronico);
                $hoja1->setCellValue('E'.$j,$value->direccion);
                if ($tipo == 11) {
                    $hoja1->setCellValue('F'.$j,$value->placa);
                    if(!is_null($value->params)) {
                        $hoja1->setCellValue('G'.$j,$this->getExplodeStringReport($value->params, 1,'@@'));
                        $hoja1->setCellValue('H'.$j,$this->getExplodeStringReport($this->getExplodeStringReport($value->params, 2,'@@'), 0,'/'));
                        $hoja1->setCellValue('I'.$j,$this->getExplodeStringReport($this->getExplodeStringReport($value->params, 2,'@@'), 1,'/'));
                    }
                    $hoja1->setCellValue('J'.$j,$value->fechaReg);
                    $hoja1->getStyle('A'.$j.':J'.$j)->applyFromArray($this->estilo_content);
                } elseif ($tipo == 22) {
                    $hoja1->setCellValue('F'.$j,$value->placa);
                    $hoja1->setCellValue('G'.$j,$value->kilometraje);
                    $hoja1->setCellValue('H'.$j,$this->getExplodeStringReport($value->marcamodelo, 0,'/'));
                    $hoja1->setCellValue('I'.$j,$this->getExplodeStringReport($value->marcamodelo, 1,'/'));
                    $hoja1->setCellValue('J'.$j,$value->fechaReg);
                    $hoja1->getStyle('A'.$j.':J'.$j)->applyFromArray($this->estilo_content);
                } elseif ($tipo == 33) {
                    if(!is_null($value->params)) {
                        $hoja1->setCellValue('F'.$j,$this->getExplodeStringReport($value->params, 0,'@@'));
                        $hoja1->setCellValue('G'.$j,$this->getExplodeStringReport($value->params, 1,'@@'));
                        $hoja1->setCellValue('H'.$j,$this->getExplodeStringReport($this->getExplodeStringReport($value->params, 2,'@@'), 0,'/'));
                        $hoja1->setCellValue('I'.$j,$this->getExplodeStringReport($this->getExplodeStringReport($value->params, 2,'@@'), 1,'/'));
                    }
                    $hoja1->setCellValue('J'.$j,$value->fechaReg);
                    $hoja1->getStyle('A'.$j.':J'.$j)->applyFromArray($this->estilo_content);
                } elseif ($tipo == 44) {
                    $hoja1->setCellValue('F'.$j,$value->asesorAuto);
                    $hoja1->setCellValue('G'.$j,$value->descripcion);
                    $hoja1->setCellValue('H'.$j,$value->fecha);
                    $hoja1->getStyle('A'.$j.':H'.$j)->applyFromArray($this->estilo_content);
                }

                

                $j++;
            }
        }
        return $fileName;
    }
    
    public function getReporteExcel($fechaI, $fechaF, $tipo, $excel) {
        
        $data = $this->getData($fechaI, $fechaF, $tipo);
        $excel->setActiveSheetIndex(0);
		$hoja1 = $excel->getActiveSheet();
		$fileName = '';
        if ($tipo == 1) {
            $fileName = 'vta_detallada'; 
            $hoja1->setTitle("vta_detallada");
            $hoja1->setCellValue('A1','mac_serv');
            $hoja1->setCellValue('B1','des_linp');
            $hoja1->setCellValue('C1','des_tprd');
            $hoja1->setCellValue('D1','des_prod');
            $hoja1->setCellValue('E1','abr_tdoc');
            $hoja1->setCellValue('F1','num_docu');
            $hoja1->setCellValue('G1','fec_docu');
            $hoja1->setCellValue('H1','num_guia');
            $hoja1->setCellValue('I1','doc_cli');
            $hoja1->setCellValue('J1','des_cli');
            $hoja1->setCellValue('K1','cantidad');
            $hoja1->setCellValue('L1','val_unit');
            $hoja1->setCellValue('M1','val_vta');
            $hoja1->setCellValue('N1','val_igv');
            $hoja1->setCellValue('O1','val_total');
            $hoja1->setCellValue('P1','val_moneda');
            $hoja1->setCellValue('Q1','val_costo');
            // $hoja1->setCellValue('Q1','val_moneda_cost');
            $hoja1->getStyle('A1:Q1')->applyFromArray($this->estilo_content);
            
            // dd($data);
            $j = 2;
            foreach ($data as $value) {
                if (in_array($value->tipoComprobante,['F','B'])) {
                    $tipo = $value->tipoComprobante.'/V';
                } else {
                    $tipo = 'N/'.$value->tipoComprobante;
                }
                $hoja1->setCellValue('A'.$j,strtoupper($value->macro));
                $hoja1->setCellValue('B'.$j,$value->descripcion);
                $hoja1->setCellValue('C'.$j,$this->getStringProducto($value->tipoProducto));
                $hoja1->setCellValue('D'.$j,$value->nombre);
                $hoja1->setCellValue('E'.$j,$tipo);
                $hoja1->setCellValue('F'.$j,$value->documento);
                $hoja1->setCellValue('G'.$j,$value->fecha);
                $hoja1->setCellValue('H'.$j,'');
                $hoja1->setCellValue('I'.$j,$value->docCliente);
                $hoja1->setCellValue('J'.$j,$value->cliente);
                $hoja1->setCellValue('K'.$j,number_format($value->cantidad,2,'.',''));
                $hoja1->setCellValue('L'.$j,number_format(($value->situacion != 'V'?0:($value->igv>0?$value->precio/1.18:$value->precio)),2,'.',''));
                $hoja1->setCellValue('M'.$j,number_format(($value->situacion != 'V'?0:($value->igv>0?$value->subtotal/1.18:$value->subtotal)),2,'.',''));
                $hoja1->setCellValue('N'.$j,number_format(($value->situacion != 'V'?0:($value->igv>0?$value->subtotal/1.18* 0.18:$value->igv)),2,'.',''));
                $hoja1->setCellValue('O'.$j,"=SUM(M$j:N$j)");
                $hoja1->setCellValue('P'.$j, "PEN");
                // $hoja1->setCellValue('N'.$j, $value->cant_items);
                // $hoja1->setCellValue('O'.$j, $value->moneda);
                
                $textCosto = [];
                if (!is_null($value->det_compra)) {
                    $textCosto = explode('-', $value->det_compra);
                } 
                if (!is_null($value->det_guia)) {
                    $textCosto = explode('-', $value->det_guia);
                }
                $hoja1->setCellValue('Q'.$j,($value->situacion != 'V'?0:(count($textCosto)>0?$textCosto[1]:'')));
                // $hoja1->setCellValue('Q'.$j,($value->situacion != 'V'?0:(count($textCosto)>0?($textCosto[0]=='S'?'PEN':'USD'):'')));
                
                $hoja1->getStyle('A'.$j.':Q'.$j)->applyFromArray($this->estilo_content);

                $j++;
            }
        } elseif($tipo == 2) {
            $fileName = 'ventas_ple'; 
            $hoja1->setTitle("ventas_ple");
            $hoja1->setCellValue('A1','CAMPO 1');
            $hoja1->setCellValue('B1','CAMPO 2');
            $hoja1->setCellValue('C1','CAMPO 3');
            $hoja1->setCellValue('D1','CAMPO 4');
            $hoja1->setCellValue('E1','CAMPO 5');
            $hoja1->setCellValue('F1','CAMPO 6');
            $hoja1->setCellValue('G1','CAMPO 7');
            $hoja1->setCellValue('H1','CAMPO 8');
            $hoja1->setCellValue('I1','CAMPO 9');
            $hoja1->setCellValue('J1','CAMPO 10');
            $hoja1->setCellValue('K1','CAMPO 11');
            $hoja1->setCellValue('L1','CAMPO 12');
            $hoja1->setCellValue('M1','CAMPO 13');
            $hoja1->setCellValue('N1','CAMPO 14');
            $hoja1->setCellValue('O1','CAMPO 15');
            $hoja1->setCellValue('P1','CAMPO 16');
            $hoja1->setCellValue('Q1','CAMPO 17');
            $hoja1->setCellValue('R1','CAMPO 18');
            $hoja1->setCellValue('S1','CAMPO 19');
            $hoja1->setCellValue('T1','CAMPO 20');
            $hoja1->setCellValue('U1','CAMPO 21');
            $hoja1->setCellValue('V1','CAMPO 22');
            $hoja1->setCellValue('W1','CAMPO 23');
            $hoja1->setCellValue('X1','CAMPO 24');
            $hoja1->setCellValue('Y1','CAMPO 25');
            $hoja1->setCellValue('Z1','CAMPO 26');
            $hoja1->setCellValue('AA1','CAMPO 27');
            $hoja1->setCellValue('AB1','CAMPO 28');
            $hoja1->setCellValue('AC1','CAMPO 29');
            $hoja1->setCellValue('AD1','CAMPO 30');
            $hoja1->setCellValue('AE1','CAMPO 31');
            $hoja1->setCellValue('AF1','CAMPO 32');
            $hoja1->setCellValue('AG1','CAMPO 33');
            $hoja1->setCellValue('AH1','CAMPO 34');
            $hoja1->setCellValue('AI1','CAMPO 35');
            $hoja1->setCellValue('AJ1','CAMPO 36');
            $hoja1->getStyle('A1:AJ1')->applyFromArray($this->estilo_content);
            
            $j = 2;
            $cont = 1;
            $constant_zero = 0.00;
            $constant_uno = 1.00;
            $contants_two = 2.00;
            foreach ($data as $value) {
                $hoja1->setCellValue('A'.$j,$value->campo1);
                $hoja1->setCellValue('B'.$j,str_pad($cont,5,'0', STR_PAD_LEFT).$value->campo2);
                $hoja1->setCellValue('C'.$j,'M'.str_pad($cont,5,'0', STR_PAD_LEFT));
                $hoja1->setCellValue('D'.$j,$value->campo4);
                $hoja1->setCellValue('E'.$j,'');
                $hoja1->setCellValue('F'.$j,$value->campo6);
                $hoja1->setCellValue('G'.$j,$value->campo7);
                $hoja1->setCellValue('H'.$j,$value->campo8);
                $hoja1->setCellValue('I'.$j,'');
                $hoja1->setCellValue('J'.$j,$value->campo10);
                $hoja1->setCellValue('K'.$j,$value->campo11);
                $hoja1->setCellValue('L'.$j,$value->campo12);
                $hoja1->setCellValue('M'.$j,$constant_zero);
                $hoja1->setCellValue('N'.$j,($value->situacion != 'V'?$constant_zero:number_format($value->campo14,2,'.','')));
                $hoja1->setCellValue('O'.$j,$constant_zero);
                $hoja1->setCellValue('P'.$j,($value->situacion != 'V'?$constant_zero:number_format($value->campo16,2,'.','')));
                $hoja1->setCellValue('Q'.$j,$constant_zero);
                $hoja1->setCellValue('R'.$j,($value->situacion != 'V'?$constant_zero:number_format($value->campo18,2,'.','')));
                $hoja1->setCellValue('S'.$j,($value->situacion != 'V'?$constant_zero:number_format($value->campo19,2,'.','')));
                $hoja1->setCellValue('T'.$j,$constant_zero);
                $hoja1->setCellValue('U'.$j,$constant_zero);
                $hoja1->setCellValue('V'.$j,$constant_zero);
                $hoja1->setCellValue('W'.$j,$constant_zero);
                $hoja1->setCellValue('X'.$j,$constant_zero);
                $hoja1->setCellValue('Y'.$j,($value->situacion != 'V'?$constant_zero:number_format($value->campo25,2,'.','')));
                $hoja1->setCellValue('Z'.$j,$value->campo26);
                $hoja1->setCellValue('AA'.$j,number_format($value->campo27,2,'.',''));
                $hoja1->setCellValue('AB'.$j,$value->campo28);
                $hoja1->setCellValue('AC'.$j,$value->campo29);
                $hoja1->setCellValue('AD'.$j,$value->campo30);
                $hoja1->setCellValue('AE'.$j,$value->campo31);
                $hoja1->setCellValue('AF'.$j,'');
                $hoja1->setCellValue('AG'.$j,'');
                $hoja1->setCellValue('AH'.$j,'');
                $hoja1->setCellValue('AI'.$j,($value->situacion!='V'?$contants_two:$constant_uno));
                $hoja1->setCellValue('AJ'.$j,'');
                $hoja1->getStyle('A'.$j.':AJ'.$j)->applyFromArray($this->estilo_content);
                $j++;
                $cont++;
            }
            
            // 
        } elseif($tipo == 3) {
            $fileName = 'compras_ple'; 
            $hoja1->setTitle("compras_ple");
            $hoja1->setCellValue('A1','ano_mes');
            $hoja1->setCellValue('B1','num_cor');
            $hoja1->setCellValue('C1','new_cor');
            $hoja1->setCellValue('D1','fec_docu');
            $hoja1->setCellValue('E1','vct_docu');
            $hoja1->setCellValue('F1','tip_comp');
            $hoja1->setCellValue('G1','ser_docu');
            $hoja1->setCellValue('H1','ano_dua');
            $hoja1->setCellValue('I1','num_docu');
            $hoja1->setCellValue('J1','imp_cero');
            $hoja1->setCellValue('K1','tip_iden');
            $hoja1->setCellValue('L1','num_iden');
            $hoja1->setCellValue('M1','des_prv');
            $hoja1->setCellValue('N1','val_cdf');
            $hoja1->setCellValue('O1','igv_cdf');
            $hoja1->setCellValue('P1','val_sdf');
            $hoja1->setCellValue('Q1','igv_sdf');
            $hoja1->setCellValue('R1','val_ded');
            $hoja1->setCellValue('S1','igv_ded');
            $hoja1->setCellValue('T1','val_exon');
            $hoja1->setCellValue('U1','val_fisc');
            $hoja1->setCellValue('V1','val_bols');
            $hoja1->setCellValue('W1','val_otro');
            $hoja1->setCellValue('X1','val_ftot');
            $hoja1->setCellValue('Y1','cdg_mon');
            $hoja1->setCellValue('Z1','cmb_docu');
            $hoja1->setCellValue('AA1','fec_otro');
            $hoja1->setCellValue('AB1','tip_otro');
            $hoja1->setCellValue('AC1','ser_otro');
            $hoja1->setCellValue('AD1','dep_dua');
            $hoja1->setCellValue('AE1','num_otro');
            $hoja1->setCellValue('AF1','fec_detr');
            $hoja1->setCellValue('AG1','num_detr');
            $hoja1->setCellValue('AH1','swt_ret');
            $hoja1->setCellValue('AI1','cls_bien');
            $hoja1->setCellValue('AJ1','ide_cont');
            $hoja1->setCellValue('AK1','err_tcmb');
            $hoja1->setCellValue('AL1','prv_nhab');
            $hoja1->setCellValue('AM1','prv_exon');
            $hoja1->setCellValue('AN1','err_dnis');
            $hoja1->setCellValue('AO1','med_pago');
            $hoja1->setCellValue('AP1','est_anot');
            $hoja1->getStyle('A1:AP1')->applyFromArray($this->estilo_content);
            
            $j = 2;
            $cont = 1;
            $constant_zero = 0.00;
            $constant_uno = 1;
            // $contants_two = 2.00;
            $contants_empty = '';
            foreach ($data as $value) {
                $hoja1->setCellValue('A'.$j,$value->campo1);
                $hoja1->setCellValue('B'.$j,str_pad($cont,5,'0', STR_PAD_LEFT).$value->campo2);
                $hoja1->setCellValue('C'.$j,'M'.str_pad($cont,5,'0', STR_PAD_LEFT));
                $hoja1->setCellValue('D'.$j,$value->campo4);
                $hoja1->setCellValue('E'.$j,$value->campo5);
                $hoja1->setCellValue('F'.$j,$value->campo6);
                $hoja1->setCellValue('G'.$j,$this->getExplodeString($value->documento,0));
                $hoja1->setCellValue('H'.$j,$contants_empty);
                $hoja1->setCellValue('I'.$j,$this->getExplodeString($value->documento,1));
                $hoja1->setCellValue('J'.$j,$contants_empty);
                $hoja1->setCellValue('K'.$j,$value->campo11);
                $hoja1->setCellValue('L'.$j,$value->campo12);
                $hoja1->setCellValue('M'.$j,$value->campo13);
                $hoja1->setCellValue('N'.$j,$contants_empty);
                $hoja1->setCellValue('O'.$j,$contants_empty);
                $hoja1->setCellValue('P'.$j,$contants_empty);
                $hoja1->setCellValue('Q'.$j,$contants_empty);
                $hoja1->setCellValue('R'.$j,$contants_empty);
                $hoja1->setCellValue('S'.$j,$contants_empty);
                $hoja1->setCellValue('T'.$j,number_format($value->campo20,2,'.',''));
                $hoja1->setCellValue('U'.$j,$constant_zero);
                $hoja1->setCellValue('V'.$j,$constant_zero);
                $hoja1->setCellValue('W'.$j,$constant_zero);
                $hoja1->setCellValue('X'.$j,number_format($value->campo24,2,'.',''));
                $hoja1->setCellValue('Y'.$j,$value->campo25);
                $hoja1->setCellValue('Z'.$j,$value->campo26);
                $hoja1->setCellValue('AA'.$j,$value->campo27);
                $hoja1->setCellValue('AB'.$j,$value->campo28);
                $hoja1->setCellValue('AC'.$j,(!is_null($value->ref)?$this->getExplodeString($value->ref,0):''));
                $hoja1->setCellValue('AD'.$j,$contants_empty);
                $hoja1->setCellValue('AE'.$j,(!is_null($value->ref)?$this->getExplodeString($value->ref,1):''));
                $hoja1->setCellValue('AF'.$j,$contants_empty);
                $hoja1->setCellValue('AG'.$j,$contants_empty);
                $hoja1->setCellValue('AH'.$j,$contants_empty);
                $hoja1->setCellValue('AI'.$j,$constant_uno);
                $hoja1->setCellValue('AJ'.$j,$contants_empty);
                $hoja1->setCellValue('AK'.$j,$contants_empty);
                $hoja1->setCellValue('AL'.$j,$contants_empty);
                $hoja1->setCellValue('AM'.$j,$contants_empty);
                $hoja1->setCellValue('AN'.$j,$contants_empty);
                $hoja1->setCellValue('AO'.$j,$contants_empty);
                $hoja1->setCellValue('AP'.$j,$value->campo35);

                $hoja1->getStyle('A'.$j.':AP'.$j)->applyFromArray($this->estilo_content);
                $j++;
                $cont++;
            }
        } elseif($tipo == 4) {
            $fileName = 'inv_valorizado'; 
            $hoja1->setTitle("inv_valorizado");
            $hoja1->setCellValue('A1','des_area');
            $hoja1->setCellValue('B1','des_mon');
            $hoja1->setCellValue('C1','des_prod');
            $hoja1->setCellValue('D1','cant_sld');
            $hoja1->setCellValue('E1','pre_sld');
            $hoja1->setCellValue('F1','tot_sld');

            $hoja1->getStyle('A1:F1')->applyFromArray($this->estilo_content);
            
            $j = 2;
            foreach ($data as $value) {
                $textCosto = [];
                if (!is_null($value->det_compra)) {
                    $textCosto = explode('-', $value->det_compra);
                } 
                if (!is_null($value->det_guia)) {
                    $textCosto = explode('-', $value->det_guia);
                }
         
                $hoja1->setCellValue('A'.$j,$value->almacen);
                $hoja1->setCellValue('B'.$j,(count($textCosto)>0?($textCosto[0]=='S'?'SOLES':'DOLARES'):''));
                $hoja1->setCellValue('C'.$j,$this->getProductoConcat($value));
                $hoja1->setCellValue('D'.$j,$value->stock_detalle);
                $hoja1->setCellValue('E'.$j,(count($textCosto)>0?$textCosto[1]:''));
                $hoja1->setCellValue('F'.$j,(count($textCosto)>0?$textCosto[1]*$value->stock_detalle:''));
 
                $hoja1->getStyle('A'.$j.':F'.$j)->applyFromArray($this->estilo_content);

                $j++;
            }
    
        } elseif($tipo == 5) {
            $fileName = 'cpra_detallada'; 
            $hoja1->setTitle("cpra_detallada");
            $hoja1->setCellValue('A1','des_linp');
            $hoja1->setCellValue('B1','des_tprd');
            $hoja1->setCellValue('C1','des_prod');
            $hoja1->setCellValue('D1','abr_tdoc');
            $hoja1->setCellValue('E1','num_docu');
            $hoja1->setCellValue('F1','fec_docu');
            $hoja1->setCellValue('G1','num_guia');
            $hoja1->setCellValue('H1','doc_cli');
            $hoja1->setCellValue('I1','des_cli');
            $hoja1->setCellValue('J1','cantidad');
            $hoja1->setCellValue('K1','val_unit');
            $hoja1->setCellValue('L1','val_cpra');
            $hoja1->setCellValue('M1','val_igv');
            $hoja1->setCellValue('N1','val_total');
            $hoja1->setCellValue('O1','val_moneda');
            // $hoja1->setCellValue('P1','val_costo');
            // $hoja1->setCellValue('Q1','val_moneda_cost');
            $hoja1->getStyle('A1:O1')->applyFromArray($this->estilo_content);
            
            // dd($data);
            $j = 2;
            foreach ($data as $value) {
                if (in_array($value->tipoDocumento,['F','B'])) {
                    $tipo = $value->tipoDocumento.'/C';
                } else {
                    $tipo = 'N/'.$value->tipoDocumento;
                }
                $hoja1->setCellValue('A'.$j,$value->descripcion);
                $hoja1->setCellValue('B'.$j,$this->getStringProducto($value->tipoProducto));
                $hoja1->setCellValue('C'.$j,$value->nombre);
                $hoja1->setCellValue('D'.$j,$tipo);
                $hoja1->setCellValue('E'.$j,$value->documento);
                $hoja1->setCellValue('F'.$j,$value->fecha);
                $hoja1->setCellValue('G'.$j,'');
                $hoja1->setCellValue('H'.$j,$value->docProveedor);
                $hoja1->setCellValue('I'.$j,$value->proveedor);
                $hoja1->setCellValue('J'.$j,number_format($value->cantidad,2,'.',''));
                $hoja1->setCellValue('K'.$j,number_format(($value->situacion != 'V'?0:$value->precio),2,'.',''));
                $hoja1->setCellValue('L'.$j,number_format(($value->situacion != 'V'?0:$value->subtotal),2,'.',''));
                $hoja1->setCellValue('M'.$j,number_format(($value->situacion != 'V'?0:($value->igv>0?$value->subtotal* 0.18:$value->igv)),2,'.',''));
                $hoja1->setCellValue('N'.$j,"=SUM(L$j:M$j)");
                $hoja1->setCellValue('O'.$j, "PEN");
                // $hoja1->setCellValue('N'.$j, $value->cant_items);
                // $hoja1->setCellValue('O'.$j, $value->moneda);
                
                $textCosto = [];
                // if (!is_null($value->det_compra)) {
                //     $textCosto = explode('-', $value->det_compra);
                // } 
                // if (!is_null($value->det_guia)) {
                //     $textCosto = explode('-', $value->det_guia);
                // }
                // $hoja1->setCellValue('P'.$j,($value->situacion != 'V'?0:(count($textCosto)>0?$textCosto[1]:'')));
                // $hoja1->setCellValue('Q'.$j,($value->situacion != 'V'?0:(count($textCosto)>0?($textCosto[0]=='S'?'PEN':'USD'):'')));
                
                $hoja1->getStyle('A'.$j.':O'.$j)->applyFromArray($this->estilo_content);

                $j++;
            }
        }

        return $fileName;
    }

    public function getData($fechaI, $fechaF, $tipo) {
        if ($tipo == 1) {
            $data = DB::select("CALL reporteDetalladoVentas(?,?)",[$fechaI, $fechaF]);
        } elseif($tipo == 2) {
            $data = DB::select("CALL reporteComprobantePLE(?,?)",[$fechaI, $fechaF]);
        } elseif($tipo == 3) {
            $data = DB::select("CALL reporteComprobantesComprasPLE(?,?)", [$fechaI, $fechaF]);
        } elseif($tipo == 4) {
            $data = DB::select("CALL reporteInventarioValorizado(?)",[$fechaF]);
        } elseif($tipo == 5) {
            $data = DB::select("CALL reporteDetalladoCompras(?,?)",[$fechaI, $fechaF]);
        }
        
        return $data;
    }

    public function getDataCliente($fechaI, $fechaF, $tipo, $cliente) {
        if ($tipo == 1) {
            $data = DB::table('ordentrabajo as ot')
                ->join('persona as cl','cl.id','=','ot.idCliente')
                ->join('trabajador as per','per.id','=','ot.idPersonal')
                ->leftjoin('trabajador as tr','tr.id','=','ot.idAsignado')
                ->join('detalleordentrabajo as detor','detor.idOrdenTrabajo','=','ot.id')
                ->join('cotizacion as ct','ct.id','=','detor.idCotizacion')
                ->join('detallecotizacion as dct','dct.idCotizacion','=','ct.id')
                ->where(function ($qq) use ($cliente) {
                    $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                    ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ot.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ot.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }

            $data = $data->select(DB::Raw("CONCAT('OD', LPAD(ot.serie,2,'0') ,'-', LPAD(ot.numero,8,'0')) as orden"),
                'dct.descripcion as detalle', DB::Raw("ROUND(dct.cantidad,2) as cantidad"),
                DB::Raw("DATE_FORMAT(dct.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                DB::Raw("CONCAT('C', LPAD(ct.serie,3,'0') ,'-', LPAD(ct.numero,8,'0')) as cotizacion"),
                DB::Raw("DATE_FORMAT(ot.fecha,'%d/%m/%Y') as fecha"),
                'ot.placa', 'ot.situacionFacturado', 'ct.kilometraje','ct.vin','ct.marcamodelo',
                DB::Raw("DATE_FORMAT(ot.inicia,'%d/%m/%Y %h:%i:%s %p') as inicia"),
                DB::Raw("DATE_FORMAT(ot.finaliza,'%d/%m/%Y %h:%i:%s %p') as finaliza"),
                DB::Raw("CONCAT(tr.apellidos,' ', tr.nombres) as trabajador"),
                'cl.documento as documentoCliente', 'ot.situacion',
                DB::Raw("CONCAT(per.apellidos,' ',per.nombres) as personal"),
                'cl.correoElectronico', 'cl.telefono as celular',
                DB::Raw("(SELECT CONCAT(v.tipoComprobante, LPAD(v.serie,3,'0') ,'-', LPAD(v.numero,8,'0')) FROM pagodetalle as pd JOIN venta as v ON v.id = pd.idVenta WHERE pd.idOrden = ot.id LIMIT 1) as venta"),
                DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                DB::Raw("CONCAT(cl.documento, '@@@', cl.telefono) as keyI")
                )
                // ->orderBy('ot.fecha','ASC')
                // ->orderBy('cl.documento','ASC')
                // ->orderBy('ot.placa','ASC')
                ->get();
        } elseif($tipo == 2) {
            $data2 = DB::table('cotizacion as ct')
                    ->join('trabajador as per','per.id','=','ct.idPersonal')
                    ->join('persona as cl','cl.id','=','ct.idCliente')
                    ->join('detallecotizacion as dct','dct.idCotizacion','=','ct.id')
                    ->where('ct.situacion','<>','U')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data2 = $data2->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data2 = $data2->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  

            
            $data2 = $data2->select('dct.descripcion as detalle', DB::Raw("ROUND(dct.cantidad,2) as cantidad"),
                DB::Raw("DATE_FORMAT(dct.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                DB::Raw("CONCAT('C', LPAD(ct.serie,3,'0') ,'-', LPAD(ct.numero,8,'0')) as cotizacion"),
                DB::Raw("DATE_FORMAT(ct.fecha,'%d/%m/%Y') as fecha"),
                'ct.placa', 'ct.situacionFacturado', 'ct.kilometraje','ct.vin','ct.marcamodelo',
                'cl.documento as documentoCliente', 'ct.situacion',
                DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                DB::Raw("CONCAT(per.apellidos,' ', per.nombres) as personal"),
                'cl.correoElectronico', 'cl.telefono as celular',
                DB::Raw("(SELECT CONCAT(v.tipoComprobante, LPAD(v.serie,3,'0') ,'-', LPAD(v.numero,8,'0')) FROM pagodetalle as pd JOIN venta as v ON v.id = pd.idVenta WHERE pd.idCotizacion = ct.id LIMIT 1) as venta"),
                DB::Raw("CONCAT(cl.documento, '@@@', cl.telefono) as keyI")
            );

            // PARA COTIZACIONES DE AUTOS
            $data = DB::table('cotizacionauto as ct')
                    ->join('trabajador as per','per.id','=','ct.idPersonal')
                    ->join('persona as cl','cl.id','=','ct.idCliente')
                    ->join('detallecotizacionauto as dct','dct.idCotizacion','=','ct.id')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  

            $data = $data->select('dct.descripcion as detalle', DB::Raw("ROUND(dct.cantidad,2) as cantidad"),
                        DB::Raw("DATE_FORMAT(dct.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                        DB::Raw("CONCAT('C', LPAD(ct.serie,3,'0') ,'-', LPAD(ct.numero,8,'0')) as cotizacion"),
                        DB::Raw("DATE_FORMAT(ct.fecha,'%d/%m/%Y') as fecha"),
                        DB::Raw("'-'  as placa"),
                        DB::Raw("'-'  as situacionFacturado"),
                        DB::Raw("'-'  as kilometraje"),
                        DB::Raw("'-'  as vin"),
                        DB::Raw("'-'  as marcamodelo"),                        
                        'cl.documento as documentoCliente', 'ct.situacion',
                        DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                        DB::Raw("CONCAT(per.apellidos,' ', per.nombres) as personal"),
                        'cl.correoElectronico', 'cl.telefono as celular',
                        DB::Raw("NULL as venta"),
                        DB::Raw("CONCAT(cl.documento, '@@@',cl.telefono) as keyI")
                    )
                    ->unionAll($data2)
                    ->get();
            // $data = DB::select("CALL reporteComprobantePLE(?,?)",[$fechaI, $fechaF]);
        } elseif($tipo == 3) {
            $data = DB::table('venta as v')
                    ->join('detalleventa as dv','dv.idVenta','=','v.id')
                    ->join('pagodetalle as pd','pd.idDetalleVenta','=','dv.id')
                    ->join('trabajador as per','per.id','=','v.idPersonal')
                    ->join('persona as cl','cl.id','=','v.idCliente')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  
            
            $data = $data->select('dv.descripcion as detalle', DB::Raw("ROUND(dv.cantidad,2) as cantidad"),
                    DB::Raw("DATE_FORMAT(dv.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                    DB::Raw("CONCAT(v.tipoComprobante, LPAD(v.serie,3,'0') ,'-', LPAD(v.numero,8,'0')) as venta"),
                    DB::Raw("DATE_FORMAT(v.fecha,'%d/%m/%Y') as fecha"),
                    'cl.documento as documentoCliente', 'v.situacion',
                    DB::Raw("(CASE WHEN pd.idCotizacion IS NOT NULL 
                    THEN (SELECT CONCAT('C', LPAD(ct.serie,3,'0') ,'-', LPAD(ct.numero,8,'0')) FROM cotizacion ct WHERE ct.id = pd.idCotizacion) 
                    ELSE (CASE WHEN pd.idOrden IS NOT NULL THEN (SELECT CONCAT('OD', LPAD(ot.serie,2,'0') ,'-', LPAD(ot.numero,8,'0')) FROM ordentrabajo as ot WHERE ot.id = pd.idOrden) 
                    ELSE NULL END) END) as referencia"),
                    DB::Raw("(CASE WHEN pd.idCotizacion IS NOT NULL 
                    THEN (SELECT CONCAT(ct.placa,'@@', ct.kilometraje, '@@', (CASE WHEN ct.marcamodelo IS NULL THEN '' ELSE ct.marcamodelo END), '@@', ct.vin) FROM cotizacion as ct WHERE ct.id = pd.idCotizacion LIMIT 1) 
                    ELSE (CASE WHEN pd.idOrden IS NOT NULL THEN (SELECT CONCAT(ct.placa,'@@', ct.kilometraje, '@@', (CASE WHEN ct.marcamodelo IS NULL THEN '' ELSE ct.marcamodelo END),'@@', ct.vin) FROM detalleordentrabajo as dto JOIN cotizacion as ct ON ct.id = dto.idCotizacion WHERE dto.idOrdenTrabajo = pd.idOrden ORDER BY dto.id ASC LIMIT 1) 
                    ELSE NULL END) END) as params"),                 
                    'v.asesorAuto',
                    DB::Raw("CONCAT(per.apellidos,' ', per.nombres) as personal"),
                    'cl.correoElectronico', 'cl.telefono as celular',
                    DB::Raw("CONCAT(cl.documento, '@@@',cl.telefono) as keyI"),
                    DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente")
                )
                ->get();
            // $data = DB::select("CALL reporteComprobantesComprasPLE(?,?)", [$fechaI, $fechaF]);
        } elseif($tipo == 4) {
            $data = DB::table('venta as v')
                    ->join('detalleventa as dv','dv.idVenta','=','v.id')
                    ->join('pagodetalle as pd','pd.idDetalleVenta','=','dv.id')
                    ->join('trabajador as per','per.id','=','v.idPersonal')
                    ->join('persona as cl','cl.id','=','v.idCliente')
                    ->whereNotNull('dv.idAuto')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  
            
            $data = $data->select('dv.descripcion as detalle', DB::Raw("ROUND(dv.cantidad,2) as cantidad"),
                    DB::Raw("DATE_FORMAT(dv.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                    DB::Raw("CONCAT(v.tipoComprobante, LPAD(v.serie,3,'0') ,'-', LPAD(v.numero,8,'0')) as venta"),
                    DB::Raw("DATE_FORMAT(v.fecha,'%d/%m/%Y') as fecha"),
                    'cl.documento as documentoCliente', 'v.situacion',
                    DB::Raw("(CASE WHEN pd.idCotizacion IS NOT NULL 
                    THEN (SELECT CONCAT('C', LPAD(ct.serie,3,'0') ,'-', LPAD(ct.numero,8,'0')) FROM cotizacion ct WHERE ct.id = pd.idCotizacion) 
                    ELSE (CASE WHEN pd.idOrden IS NOT NULL THEN (SELECT CONCAT('OD', LPAD(ot.serie,2,'0') ,'-', LPAD(ot.numero,8,'0')) FROM ordentrabajo as ot WHERE ot.id = pd.idOrden) 
                    ELSE NULL END) END) as referencia"),
                    'v.asesorAuto',
                    DB::Raw("CONCAT(per.apellidos,' ', per.nombres) as personal"),
                    'cl.correoElectronico', 'cl.telefono as celular',
                    DB::Raw("CONCAT(cl.documento, '@@@',cl.telefono) as keyI"),
                    DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente")
                )
                ->get();
            // $data = DB::select("CALL reporteComprobantesComprasPLE(?,?)", [$fechaI, $fechaF]);
        } elseif ($tipo == 5) {
            $data = DB::select("CALL reporteClientesMarketing(?,?,?)",[$fechaI, $fechaF, '%'.$cliente.'%']);
        } elseif($tipo == 11) {
            $data = DB::table('ordentrabajo as ot')
                ->join('persona as cl','cl.id','=','ot.idCliente')
                ->where(function ($qq) use ($cliente) {
                    $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                    ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ot.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ot.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }

            $data = $data->select(
                    'ot.placa',
                    DB::Raw("(SELECT CONCAT(c.placa,'@@', c.kilometraje,'@@', c.marcamodelo) FROM cotizacion c JOIN detalleordentrabajo as dt ON dt.idCotizacion = c.id WHERE dt.idOrdenTrabajo = ot.id ORDER BY dt.id ASC LIMIT 1) as params"),
                    'cl.documento', 'cl.direccion', 'cl.correoElectronico', 'cl.telefono as celular',
                    DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                    DB::Raw("DATE_FORMAT(ot.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                    DB::Raw("(SELECT (CASE WHEN pd.idOrden IS NOT NULL THEN (SELECT CONCAT(cot.placa, '@@', cot.kilometraje,'@@', cot.marcamodelo) FROM cotizacion as cot JOIN detalleordentrabajo as dt ON dt.idCotizacion = cot.id WHERE dt.idOrdenTrabajo = pd.idOrden ORDER BY dt.id ASC LIMIT 1) ELSE (SELECT CONCAT(ct.placa,'@@', ct.kilometraje,'@@',ct.marcamodelo) FROM cotizacion as ct WHERE ct.id = pd.idCotizacion LIMIT 1) END) FROM pagodetalle as pd WHERE pd.idOrden = ot.id AND (pd.idOrden IS NOT NULL OR pd.idCotizacion IS NOT NULL) LIMIT 1) as params")
                )
                ->distinct()
                ->orderBy('cl.documento','ASC')
                ->get();

        } elseif($tipo == 22) {
            $data2 = DB::table('cotizacion as ct')
                    ->join('persona as cl','cl.id','=','ct.idCliente')
                    ->where('ct.situacion','<>','U')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data2 = $data2->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data2 = $data2->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  

            
            $data2 = $data2->select('cl.documento','cl.direccion','cl.correoElectronico', 'cl.telefono as celular', 'ct.placa',
                'ct.kilometraje', 'ct.marcamodelo',
                DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                DB::Raw("DATE_FORMAT(ct.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg")
            );

            // PARA COTIZACIONES DE AUTOS
            $data = DB::table('cotizacionauto as ct')
                    ->join('persona as cl','cl.id','=','ct.idCliente')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(ct.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  

            $data = $data->select('cl.documento','cl.direccion','cl.correoElectronico', 'cl.telefono as celular', DB::Raw("NULL as placa"),
                        DB::Raw("NULL as kilometraje"), DB::Raw("NULL as marcamodelo"),
                        DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                        DB::Raw("DATE_FORMAT(ct.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg")
                    )
                    ->unionAll($data2)
                    ->distinct()
                    ->orderBy('documento','ASC')
                    ->get();
        } elseif($tipo == 33) {
            $data = DB::table('venta as v')
                    ->join('persona as cl','cl.id','=','v.idCliente')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  
            
            $data = $data->select('cl.documento', 'cl.direccion', 'cl.correoElectronico', 'cl.telefono as celular',
                    DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                    DB::Raw("DATE_FORMAT(v.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"),
                    DB::Raw("(SELECT (CASE WHEN pd.idOrden IS NOT NULL THEN (SELECT CONCAT(cot.placa, '@@', cot.kilometraje,'@@', cot.marcamodelo) FROM cotizacion as cot JOIN detalleordentrabajo as dt ON dt.idCotizacion = cot.id WHERE dt.idOrdenTrabajo = pd.idOrden ORDER BY pd.id ASC LIMIT 1) ELSE (SELECT CONCAT(ct.placa,'@@', ct.kilometraje,'@@',ct.marcamodelo) FROM cotizacion as ct WHERE ct.id = pd.idCotizacion LIMIT 1) END) FROM pagodetalle as pd WHERE pd.idVenta = v.id AND (pd.idOrden IS NOT NULL OR pd.idCotizacion IS NOT NULL) LIMIT 1) as params")
                )
                ->distinct()
                ->orderBy('cl.documento','ASC')
                ->get();
        } elseif($tipo == 44) {
            $data = DB::table('venta as v')
                    ->join('detalleventa as dv','dv.idVenta','=','v.id')
                    ->join('persona as cl','cl.id','=','v.idCliente')
                    ->whereNotNull('dv.idAuto')
                    ->where(function ($qq) use ($cliente) {
                        $qq->where('cl.documento','LIKE','%'.$cliente.'%')
                        ->orWhere(DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END)"),'LIKE', '%'.$cliente.'%');
                    });

            if ($fechaI != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'>=', $fechaI);
            }

            if ($fechaF != '') {
                $data = $data->where(DB::Raw("DATE_FORMAT(v.created_at, '%Y-%m-%d')"),'<=', $fechaF);
            }  
            
            $data = $data->select('cl.documento','cl.direccion', 'cl.correoElectronico', 'cl.telefono as celular',
                    DB::Raw("(CASE cl.tipoDocumento WHEN 'PN' THEN CONCAT(cl.apellidos,' ', cl.nombres) ELSE cl.razonSocial END) as cliente"),
                    DB::Raw("DATE_FORMAT(v.created_at,'%d/%m/%Y %h:%i:%s %p') as fechaReg"), DB::Raw("DATE_FORMAT(v.fecha,'%d/%m/%Y') as fecha"),
                    'dv.descripcion', 'v.asesorAuto'
                )
                ->distinct()
                ->orderBy('cl.documento','ASC')
                ->get();

        }
        
        return $data;
    }


    public function getProductoConcat ($elemento) {
        $return = $elemento->nombre2; 
        if ($elemento->nombre != '') {
            $return = $elemento->nombre;
            // if($elemento->medida != '-') {
            //     $return .= ", Medida: $elemento->medida";
            // }

            // if($elemento->tipollanta != '-') {
            //     $return .= ", Tipo de Llanta: $elemento->tipollanta";
            // }

            // if($elemento->marca != '-') {
            //     $return .= ", Marca: $elemento->marca";
            // }

            // if($elemento->modelo != '-') {
            //     $return .= ", Modelo: $elemento->modelo";
            // }
            
            // if($elemento->sistema != '-') {
            //     $return .= ", Sistema: $elemento->sistema";
            // }

            // if($elemento->medida != '-') {
            //     $return .= ", Medida: $elemento->medida";
            // }
        }
        return $return;
    }
    
    public function getStringProducto ($tipo) {
        $return = '';
        switch ($tipo) {
            case 'A':
                $return = 'Accesorios/Repuestos';
                break;
            case 'B':
                $return = 'Bater铆as';
                break;
            case 'LL':
                $return = 'Neum谩ticos';
                break;
            case 'M':
                $return = 'Muelles';
                break;
            case 'I':
                $return = 'Insumos';
                break;
            default: 
                $return = $tipo;
                break;
        }

        return $return;
    }

    public function getExplodeString($string, $index) {
        try {
            $arrString = explode('-',$string);
            return $arrString[$index];
        } catch (\Exception $ex) {
            return '-';
        }
    }

    public function getExplodeStringReport($string, $index, $separator) {
        try {
            $arrString = explode($separator,$string);
            return $arrString[$index];
        } catch (\Exception $ex) {
            return '-';
        }
    }

    public function getExplodeMarcaModeloString($string, $index) {
        try {
            $arrString = explode('/',$string);
            return $arrString[$index];
        } catch (\Exception $ex) {
            return '-';
        }
    }


    public function saveElementos (Request $request) {
        dd("Inhabilitado por seguridad");
        $pagos = PagoDetalle::whereNotNull('idCotizacion')
                    ->orWhereNotNull('idOrden')
                    ->get();
        
        foreach ($pagos as $pg) {
            $dtv = DB::table('detalleventa')
                    ->where('id',$pg->idDetalleVenta)->first();
            if (!is_null($dtv)) {
                if (!is_null($pg->idOrden)) {
                    $detalles_orden = DB::table('detalleordentrabajo')->where('idOrdenTrabajo',$pg->idOrden)
                                        ->get();
                    foreach ($detalles_orden as $d_o) {
                        if (!is_null($dtv->idProducto)) {
                            $dcot = DB::table('detallecotizacion')->where('idCotizacion',$d_o->idCotizacion)
                                    ->where('cantidad',$dtv->cantidad)
                                    ->where('idProducto',$dtv->idProducto)
                                    // ->where(function ($qq) use ($dtv) {
                                    //     $qq ->orwhere('idServicio', $dtv->idServicio);
                                    // })
                                    ->first();
                            // if (!is_null($dcot)) {
                            //     $dHom = new DetalleHomologacion;
                            //     $dHom->idDetalleVenta = $dtv->id;
                            //     $dHom->idDetalleCotizacion = $dcot->id;
                            //     $dHom->save();
                            // }
                        } else {
                            $dcot = DB::table('detallecotizacion')->where('idCotizacion',$d_o->idCotizacion)
                                    ->where('cantidad',$dtv->cantidad)
                                    ->where('idServicio',$dtv->idServicio)
                                    // ->where(function ($qq) use ($dtv) {
                                    //     $qq ->orwhere('idServicio', $dtv->idServicio);
                                    // })
                                    ->first();
                        }

                        if (!is_null($dcot)) {
                            $dHom = new DetalleHomologacion;
                            $dHom->idDetalleVenta = $dtv->id;
                            $dHom->idDetalleCotizacion = $dcot->id;
                            $dHom->save();
                        }
                
                  
                    }
                } elseif(!is_null($pg->idCotizacion)) {
                    if (!is_null($dtv->idProducto)) {
                        $dcot = DB::table('detallecotizacion')->where('idCotizacion',$pg->idCotizacion)
                            ->where('cantidad',$dtv->cantidad)
                            ->where('idProducto',$dtv->idProducto)
                            // ->where(function ($qq) use ($dtv) {
                            //     $qq ->orwhere('idServicio', $dtv->idServicio);
                            // })
                            ->first();
                    } else {
                        $dcot = DB::table('detallecotizacion')->where('idCotizacion',$pg->idCotizacion)
                                ->where('cantidad',$dtv->cantidad)
                                ->where('idServicio',$dtv->idServicio)
                                // ->where(function ($qq) use ($dtv) {
                                //     $qq ->orwhere('idServicio', $dtv->idServicio);
                                // })
                                ->first();
                    
                    }

                    if (!is_null($dcot)) {
                        $dHom = new DetalleHomologacion;
                        $dHom->idDetalleVenta = $dtv->id;
                        $dHom->idDetalleCotizacion = $dcot->id;
                        $dHom->save();
                    }
                
                }
            }
        }

        dd("Ok, terminado");
    }
}
